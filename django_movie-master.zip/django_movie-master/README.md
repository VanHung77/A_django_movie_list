# django_movie
Website 'Film Library' in Python3 and Django3 Framework

## Implemented:
- Catecories
- Genres
- Films
- Stills from the film
- Directors\Actors
- Rating stars
- Comments
- Filters
